@echo off
rem Diagnostico da instalacao do GTA Co-op: confere os arquivos na pasta do GTA V Enhanced e grava um relatorio
rem (diagnostico-gtacoop.txt) na Area de Trabalho. NAO muda nada na pasta do jogo.
rem Opcional: diagnostico-gtacoop.bat "D:\caminho\da\pasta\do\jogo"
set "GTACOOP_PASTA=%~1"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$f='%~f0'; $p=(Get-Content -LiteralPath $f -Raw -Encoding UTF8) -split ('#'+'#POWERSHELL#'+'#'); Invoke-Expression $p[$p.Length-1]"
echo.
pause
exit /b

##POWERSHELL##
$ErrorActionPreference = 'Continue'
$saida = New-Object System.Collections.Generic.List[string]
function L([string]$t = '') { $saida.Add($t); Write-Host $t }

# ---------- achar a pasta do jogo ----------
$candidatas = New-Object System.Collections.Generic.List[string]
if ($env:GTACOOP_PASTA) { $candidatas.Add($env:GTACOOP_PASTA.Trim('"')) }
$batDir = Split-Path -Parent $f
$candidatas.Add($batDir); $candidatas.Add((Split-Path -Parent $batDir))
$dat = Join-Path $env:ProgramData 'Epic\UnrealEngineLauncher\LauncherInstalled.dat'
if (Test-Path -LiteralPath $dat) { try { (Get-Content -LiteralPath $dat -Raw | ConvertFrom-Json).InstallationList | ForEach-Object { if ($_.InstallLocation) { $candidatas.Add($_.InstallLocation) } } } catch { } }
$libs = New-Object System.Collections.Generic.List[string]
foreach ($chave in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam') {
    try { $v = Get-ItemProperty -Path $chave -ErrorAction Stop; foreach ($s in @($v.SteamPath, $v.InstallPath)) { if ($s) { $libs.Add($s.Replace('/', '\')) } } } catch { }
}
foreach ($s in @($libs)) {
    $vdf = Join-Path $s 'steamapps\libraryfolders.vdf'
    if (Test-Path -LiteralPath $vdf) { foreach ($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw), '"path"\s+"([^"]+)"')) { $libs.Add($m.Groups[1].Value.Replace('\\', '\')) } }
}
foreach ($d in (Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
    foreach ($sub in 'SteamLibrary', 'Steam', 'Program Files (x86)\Steam', 'Program Files\Steam', 'Jogos\SteamLibrary', 'Games\SteamLibrary') { $libs.Add((Join-Path $d.Root $sub)) }
    foreach ($sub in 'Program Files\Rockstar Games\Grand Theft Auto V Enhanced', 'Epic Games\GTAVEnhanced', 'Program Files\Epic Games\GTAVEnhanced') { $candidatas.Add((Join-Path $d.Root $sub)) }
}
foreach ($lib in $libs) {
    $common = Join-Path $lib 'steamapps\common'
    if (Test-Path -LiteralPath $common) { Get-ChildItem -LiteralPath $common -Directory -ErrorAction SilentlyContinue | ForEach-Object { $candidatas.Add($_.FullName) } }
}
$jogo = $null
foreach ($c in $candidatas) { if ($c -and (Test-Path -LiteralPath (Join-Path $c 'GTA5_Enhanced.exe'))) { $jogo = (Resolve-Path -LiteralPath $c).Path.TrimEnd('\'); break } }
if (-not $jogo) {
    Write-Host "Nao achei a pasta do GTA V Enhanced sozinho." -ForegroundColor Yellow
    $r = Read-Host "Cole o caminho da pasta do jogo (onde fica o GTA5_Enhanced.exe) e aperte Enter"
    $r = $r.Trim().Trim('"')
    if ($r -and (Test-Path -LiteralPath (Join-Path $r 'GTA5_Enhanced.exe'))) { $jogo = (Resolve-Path -LiteralPath $r).Path.TrimEnd('\') }
    else { Write-Host "Nessa pasta nao tem GTA5_Enhanced.exe." -ForegroundColor Red; return }
}

# ---------- cabeçalho ----------
L "=== DIAGNOSTICO GTA CO-OP  $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ==="
L "Pasta do jogo: $jogo"
$exe = Get-Item -LiteralPath (Join-Path $jogo 'GTA5_Enhanced.exe')
L ("Versao do jogo (GTA5_Enhanced.exe): {0}   (testada pelo mod: 1.0.1158.16)" -f $exe.VersionInfo.FileVersion)
$loja = if (Test-Path -LiteralPath (Join-Path $jogo '.egstore')) { 'Epic' } elseif ($jogo -match '\\steamapps\\common\\') { 'Steam' } else { 'outra/desconhecida' }
L "Loja: $loja"
$jogando = @(Get-Process -Name 'GTA5_Enhanced' -ErrorAction SilentlyContinue).Count -gt 0
L "Jogo aberto agora: $(if ($jogando) { 'sim' } else { 'nao' })"
L ""

# ---------- arquivos esperados ----------
L "=== ARQUIVOS NECESSARIOS (soltos na pasta do jogo) ==="
$esperados = [ordered]@{
    'ScriptHookV.dll'            = 'ScriptHookV (baixar em dev-c.com)'
    'dinput8.dll'                = 'carregador de mods (do zip do ScriptHookV)'
    'xinput1_4.dll'              = 'carregador de mods (do zip do ScriptHookV)'
    'args.txt'                   = 'desliga o BattlEye (do zip do ScriptHookV)'
    'ScriptHookVDotNet.asi'      = 'ScriptHookVDotNet (no zip do GTA Co-op)'
    'ScriptHookVDotNet.ini'      = 'ScriptHookVDotNet'
    'ScriptHookVDotNet2.dll'     = 'ScriptHookVDotNet'
    'ScriptHookVDotNet3.dll'     = 'ScriptHookVDotNet'
    'MinHook.x64.dll'            = 'ScriptHookVDotNet'
    'gtacoop.asi'                = 'GTA Co-op'
    'gtacoop\core.dll'           = 'GTA Co-op'
    'gtacoop\config.ini'         = 'GTA Co-op'
    'scripts\GtaCoop.Game.dll'   = 'GTA Co-op'
}
$faltam = 0
foreach ($k in $esperados.Keys) {
    $ok = Test-Path -LiteralPath (Join-Path $jogo $k) -PathType Leaf
    if (-not $ok) { $faltam++ }
    L ("  [{0}] {1,-28} {2}" -f $(if ($ok) { ' OK ' } else { 'FALTA' }), $k, $esperados[$k])
}
L ""

# ---------- arquivos no lugar errado ----------
L "=== ARQUIVOS DO MOD EM SUBPASTAS (lugar errado?) ==="
$nomes = 'ScriptHookV.dll', 'dinput8.dll', 'ScriptHookVDotNet.asi', 'gtacoop.asi', 'GtaCoop.Game.dll', 'core.dll', 'args.txt'
$errados = Get-ChildItem -LiteralPath $jogo -Recurse -File -Force -ErrorAction SilentlyContinue |
    Where-Object { $nomes -contains $_.Name } |
    Where-Object { $rel =$_.FullName.Substring($jogo.Length + 1); -not $esperados.Contains($rel) -and $rel -notlike 'GTAV-arquivos-removidos*' }
if ($errados) { $errados | ForEach-Object { L ("  ATENCAO: {0}" -f $_.FullName.Substring($jogo.Length + 1)) } } else { L "  nenhum" }
# Pasta com o nome do zip (Extrair tudo do Windows)
$pastaZip = Get-ChildItem -LiteralPath $jogo -Directory -Force | Where-Object { $_.Name -like 'gta-coop*' -or $_.Name -like 'ScriptHookV*' -or $_.Name -like 'ScriptHookVDotNet*' }
foreach ($p in $pastaZip) { L ("  ATENCAO: pasta '{0}' dentro da pasta do jogo: o conteudo dela precisa ficar solto na pasta do jogo" -f $p.Name) }
L ""

# ---------- logs ----------
L "=== LOGS (cada parte so cria o seu log se carregar) ==="
foreach ($log in 'asiloader.log', 'ScriptHookV.log', 'ScriptHookVDotNet.log', 'gtacoop\logs\gtacoop.log') {
    $c = Join-Path $jogo $log
    if (Test-Path -LiteralPath $c) {
        $i = Get-Item -LiteralPath $c
        L ("--- {0}  ({1:N0} bytes, {2:yyyy-MM-dd HH:mm})" -f $log, $i.Length, $i.LastWriteTime)
        Get-Content -LiteralPath $c -Tail 25 -ErrorAction SilentlyContinue | ForEach-Object { L ("    " + $_) }
    } else {
        L ("--- {0}: NAO EXISTE" -f $log)
    }
}
L ""

# ---------- resumo ----------
L "=== RESUMO ==="
if ($faltam -eq 0 -and -not $errados -and -not $pastaZip) { L "  Todos os arquivos estao no lugar." } else { L "  Faltam $faltam arquivo(s) e/ou ha arquivos no lugar errado (veja acima)." }
if (-not (Test-Path -LiteralPath (Join-Path $jogo 'asiloader.log'))) { L "  O carregador de mods nunca rodou (sem asiloader.log): confira dinput8.dll e xinput1_4.dll soltos na pasta do jogo." }
elseif (-not (Test-Path -LiteralPath (Join-Path $jogo 'ScriptHookVDotNet.log'))) { L "  O carregador rodou, mas o ScriptHookVDotNet nao iniciou: veja o ScriptHookV.log acima (versao do jogo?)." }
L ""

# ---------- lista completa ----------
L "=== TODOS OS ARQUIVOS DA PASTA DO JOGO ==="
Get-ChildItem -LiteralPath $jogo -Recurse -Force -ErrorAction SilentlyContinue | Sort-Object FullName | ForEach-Object {
    $rel = $_.FullName.Substring($jogo.Length + 1)
    if ($_.PSIsContainer) { $saida.Add(("  {0,-16} {1,14}  {2}\" -f $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm'), '<pasta>', $rel)) }
    else { $saida.Add(("  {0,-16} {1,14:N0}  {2}" -f $_.LastWriteTime.ToString('yyyy-MM-dd HH:mm'), $_.Length, $rel)) }
}

$desk = [Environment]::GetFolderPath('Desktop')
$arq = Join-Path $desk 'diagnostico-gtacoop.txt'
[IO.File]::WriteAllLines($arq, $saida, (New-Object Text.UTF8Encoding($true)))
# Zip com o relatório + os logs de medição da sincronização (decisão 73) + o log do mod, para o comparar-sessao.ps1.
$zip = Join-Path $desk 'diagnostico-gtacoop.zip'
$tmp = Join-Path $env:TEMP ('gtacoop-diag-' + [Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force -Path $tmp | Out-Null
Copy-Item -LiteralPath $arq -Destination $tmp
$sync = Join-Path $jogo 'gtacoop\logs\sync'
$nSync = 0
if (Test-Path -LiteralPath $sync) {
    New-Item -ItemType Directory -Force -Path (Join-Path $tmp 'sync') | Out-Null
    # as 6 gravações mais novas (cada sessão grava um arquivo por lado)
    Get-ChildItem -LiteralPath $sync -Filter '*.jsonl' -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 6 |
        ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $tmp 'sync'); $nSync++ }
}
$glog = Join-Path $jogo 'gtacoop\logs\gtacoop.log'
if (Test-Path -LiteralPath $glog) { Copy-Item -LiteralPath $glog -Destination $tmp }
foreach ($x in 'ScriptHookV.log', 'ScriptHookVDotNet.log', 'asiloader.log') { $p = Join-Path $jogo $x; if (Test-Path -LiteralPath $p) { Copy-Item -LiteralPath $p -Destination $tmp } }
if (Test-Path -LiteralPath $zip) { Remove-Item -LiteralPath $zip -Force }
try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::CreateFromDirectory($tmp, $zip)
} catch { Write-Host ("Nao consegui criar o zip: " + $_.Exception.Message) -ForegroundColor Yellow }
Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "Relatorio gravado em: $arq" -ForegroundColor Green
if (Test-Path -LiteralPath $zip) { Write-Host "Zip para mandar (relatorio + $nSync log(s) de sincronizacao + logs do mod): $zip" -ForegroundColor Green }
Write-Host "Mande o zip para quem esta te ajudando."
if (-not $env:GTACOOP_SEM_NOTEPAD) { Start-Process notepad.exe $arq }
