﻿<#
.SYNOPSIS
  Cria (ou remove, com -Remover) a regra do Firewall do Windows que deixa o host do gta-coop receber
  pacotes UDP na porta do co-op (padrão 27500). É PARA O USUÁRIO RODAR, como administrador, no PC do HOST.

.DESCRIPTION
  O que faz:
    - cria UMA regra de ENTRADA, protocolo UDP, só na porta pedida, permitindo a conexão, nos perfis de rede
      escolhidos (padrão: Público, que é como o Windows costuma classificar a rede do Radmin VPN);
    - nome da regra: "gta-coop UDP <porta>" (fácil de achar em "Firewall do Windows com Segurança Avançada");
    - não mexe em nenhuma outra regra, não desliga o firewall e não abre outras portas;
    - -Remover apaga só a regra com esse nome.
  Precisa de administrador (o Windows só deixa admin mudar o firewall). Sem admin, explica e para (código 2).
  -SoMostrar mostra o que faria e o comando equivalente com netsh, sem mudar nada (não precisa de admin).
  O jogador 2 (cliente) NÃO precisa desta regra: ele só envia e recebe respostas.

  Comando equivalente com netsh (o script mostra o da porta escolhida):
    netsh advfirewall firewall add rule name="gta-coop UDP 27500" dir=in action=allow protocol=UDP localport=27500 profile=public
    netsh advfirewall firewall delete rule name="gta-coop UDP 27500"

  Códigos de saída: 0 = ok · 1 = erro do Windows · 2 = precisa de administrador.

.EXAMPLE
  .\tools\firewall-radmin.ps1 -SoMostrar
  .\tools\firewall-radmin.ps1                       # cria a regra para a porta 27500 no perfil Público
  .\tools\firewall-radmin.ps1 -Porta 27600 -Perfis Public,Private
  .\tools\firewall-radmin.ps1 -Remover
#>
param(
    [ValidateRange(1, 65535)]
    [int]$Porta = 27500,
    # Perfis de rede: Public (o Radmin costuma cair aqui), Private, Domain.
    [ValidateSet('Public', 'Private', 'Domain')]
    [string[]]$Perfis = @('Public'),
    [switch]$Remover,
    [switch]$SoMostrar
)

$ErrorActionPreference = 'Stop'
$nome = "gta-coop UDP $Porta"
$perfilNetsh = ($Perfis | ForEach-Object { $_.ToLower() }) -join ','
$nomesPt = @{ Public = 'Público'; Private = 'Privado'; Domain = 'Domínio' }
$perfisPt = ($Perfis | ForEach-Object { $nomesPt[$_] }) -join ', '

if ($Remover) {
    $netsh = "netsh advfirewall firewall delete rule name=`"$nome`""
    Write-Host "Vai REMOVER a regra de firewall `"$nome`" (só ela)."
} else {
    $netsh = "netsh advfirewall firewall add rule name=`"$nome`" dir=in action=allow protocol=UDP localport=$Porta profile=$perfilNetsh"
    Write-Host "Vai CRIAR a regra de firewall `"$nome`":"
    Write-Host "  entrada, UDP, porta $Porta, permitir, perfis: $perfisPt"
    Write-Host "  Serve para o host do gta-coop receber o jogador 2 pelo Radmin VPN. Nada mais é alterado."
}
Write-Host "Comando equivalente com netsh:"
Write-Host "  $netsh"

# Em que perfil está a rede do Radmin (só informativo).
try {
    $radmin = Get-NetConnectionProfile -ErrorAction Stop | Where-Object { $_.InterfaceAlias -like '*Radmin*' }
    if ($radmin) {
        foreach ($r in $radmin) {
            $cat = "$($r.NetworkCategory)"
            Write-Host "Rede do Radmin: `"$($r.InterfaceAlias)`" está no perfil $cat."
            if (-not $Remover -and $Perfis -notcontains $cat -and $cat -ne 'DomainAuthenticated') {
                Write-Host "  Atenção: esse perfil não está em -Perfis. Rode de novo com -Perfis $cat (ou $cat,Public)." -ForegroundColor Yellow
            }
        }
    } else {
        Write-Host 'Rede do Radmin não encontrada (o Radmin VPN está instalado e conectado?). A regra vale mesmo assim.'
    }
} catch { }

if ($SoMostrar) { Write-Host '(-SoMostrar: nada foi alterado)'; exit 0 }

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host ''
    Write-Host 'Precisa de administrador para mudar o firewall.' -ForegroundColor Red
    Write-Host 'Abra o PowerShell como administrador (botão direito > "Executar como administrador"),'
    Write-Host "vá para a pasta do projeto e rode de novo: .\tools\firewall-radmin.ps1 $(if ($Remover) { '-Remover' } else { "-Porta $Porta" })"
    exit 2
}

try {
    if ($Remover) {
        $r = Get-NetFirewallRule -DisplayName $nome -ErrorAction SilentlyContinue
        if (-not $r) { Write-Host "A regra `"$nome`" não existe: nada a remover."; exit 0 }
        Remove-NetFirewallRule -DisplayName $nome
        Write-Host "Regra `"$nome`" removida." -ForegroundColor Green
    } else {
        $r = Get-NetFirewallRule -DisplayName $nome -ErrorAction SilentlyContinue
        if ($r) {
            Write-Host "A regra `"$nome`" já existe; atualizando os perfis para: $perfisPt."
            Set-NetFirewallRule -DisplayName $nome -Profile $Perfis -Enabled True -Action Allow
        } else {
            New-NetFirewallRule -DisplayName $nome -Description 'gta-coop: o host recebe o jogador 2 (UDP). Criada por tools\firewall-radmin.ps1.' `
                -Direction Inbound -Protocol UDP -LocalPort $Porta -Action Allow -Profile $Perfis | Out-Null
            Write-Host "Regra `"$nome`" criada." -ForegroundColor Green
        }
        Write-Host "Para desfazer: .\tools\firewall-radmin.ps1 -Porta $Porta -Remover"
    }
    exit 0
} catch {
    Write-Host "Erro do Windows: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
