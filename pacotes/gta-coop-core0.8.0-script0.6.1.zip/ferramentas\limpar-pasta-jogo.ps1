﻿# Deixa a pasta do GTA V Enhanced (Epic ou Steam) só com os arquivos originais do jogo.
#
# Como sabe o que é original:
#   - Epic: lê o manifesto da própria Epic (<jogo>\.egstore\*.manifest), que lista cada arquivo instalado pelo jogo.
#     Tudo o que não está nele veio de fora (mods, logs de mods, restos de instalações antigas): CERTEZA.
#   - Steam (ou sem manifesto): usa a lista arquivos-originais-gtav-enhanced.txt, ao lado deste script (tirada do
#     manifesto da Epic; os arquivos do jogo têm os mesmos nomes). Como a Steam pode ter arquivos próprios, aqui o script
#     é cauteloso: só move o que RECONHECE como mod (ScriptHookV, .asi, pastas scripts/mods, logs…); o resto aparece
#     como "não reconhecido" e só sai se você confirmar (ou com -IncluirDesconhecidos). Se algo do jogo sair por engano,
#     "Verificar integridade dos arquivos" da Steam traz de volta.
#
# NADA É APAGADO: o que sai é MOVIDO para <pasta ao lado do jogo>\GTAV-arquivos-removidos\<data_hora>\, com a mesma
# estrutura de pastas e uma lista (lista.txt). Para desfazer, copie de volta para a pasta do jogo.
#
# Modos:
#   Listar    só mostra o que não é original (não mexe em nada)
#   Original  tira TUDO o que não é original (inclusive ScriptHookV, ScriptHookVDotNet e o GTA Co-op)
#   Residuos  tira só o que não é original nem dos mods de base / GTA Co-op (mantém ScriptHookV, SHVDNE e o GTA Co-op)
# Sem -Modo, pergunta num menu.
#
# Uso: limpar-pasta-jogo.bat   (ou: powershell -ExecutionPolicy Bypass -File limpar-pasta-jogo.ps1 [-Pasta D:\...] [-Modo Listar|Original|Residuos] [-Sim])

param(
    [string]$Pasta,
    [ValidateSet('', 'Listar', 'Original', 'Residuos')][string]$Modo = '',
    [switch]$Sim,
    [switch]$IncluirDesconhecidos,   # Steam: move também o que não está na lista nem parece mod
    [string]$GerarLista              # (desenvolvimento) grava a lista de originais lida do manifesto da Epic neste arquivo
)

$ErrorActionPreference = 'Stop'

function Sair([int]$codigo, [string]$texto) {
    if ($texto) { Write-Host $texto -ForegroundColor $(if ($codigo -eq 0) { 'Green' } else { 'Red' }) }
    exit $codigo
}

# ---------- 1. Achar a pasta do jogo ----------
function Achar-Pasta {
    if ($Pasta) { return $Pasta }
    # Lista de jogos instalados da Epic
    $dat = Join-Path $env:ProgramData 'Epic\UnrealEngineLauncher\LauncherInstalled.dat'
    if (Test-Path -LiteralPath $dat) {
        try {
            $lista = (Get-Content -LiteralPath $dat -Raw | ConvertFrom-Json).InstallationList
            foreach ($item in $lista) {
                if ($item.InstallLocation -and (Test-Path -LiteralPath (Join-Path $item.InstallLocation 'GTA5_Enhanced.exe'))) { return $item.InstallLocation }
            }
        } catch { }
    }
    # Bibliotecas da Steam (steamapps\libraryfolders.vdf): procura o GTA5_Enhanced.exe em steamapps\common\*
    $steam = $null
    foreach ($chave in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam') {
        try { $v = Get-ItemProperty -Path $chave -ErrorAction Stop; $steam = if ($v.SteamPath) { $v.SteamPath } else { $v.InstallPath }; if ($steam) { break } } catch { }
    }
    if ($steam) {
        $libs = New-Object System.Collections.Generic.List[string]
        $libs.Add($steam.Replace('/', '\'))
        $vdf = Join-Path $steam 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) {
            foreach ($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw), '"path"\s+"([^"]+)"')) { $libs.Add($m.Groups[1].Value.Replace('\\', '\')) }
        }
        foreach ($lib in $libs) {
            $common = Join-Path $lib 'steamapps\common'
            if (-not (Test-Path -LiteralPath $common)) { continue }
            foreach ($d in (Get-ChildItem -LiteralPath $common -Directory -ErrorAction SilentlyContinue)) {
                if (Test-Path -LiteralPath (Join-Path $d.FullName 'GTA5_Enhanced.exe')) { return $d.FullName }
            }
        }
    }
    # O .bat colocado dentro da pasta do jogo
    foreach ($p in @($PSScriptRoot, (Split-Path -Parent $PSScriptRoot))) {
        if ($p -and (Test-Path -LiteralPath (Join-Path $p 'GTA5_Enhanced.exe'))) { return $p }
    }
    return $null
}

$jogo = Achar-Pasta
if (-not $jogo -or -not (Test-Path -LiteralPath (Join-Path $jogo 'GTA5_Enhanced.exe'))) {
    Sair 2 "Não achei a pasta do GTA V Enhanced. Rode de novo com: -Pasta ""D:\caminho\do\jogo"" (a pasta onde está o GTA5_Enhanced.exe)."
}
$jogo = (Resolve-Path -LiteralPath $jogo).Path.TrimEnd('\')
Write-Host "Pasta do jogo: $jogo"

# ---------- 2. Ler o manifesto da Epic ----------
$manifestos = @(Get-ChildItem -LiteralPath (Join-Path $jogo '.egstore') -Filter '*.manifest' -Force -ErrorAction SilentlyContinue)
$arquivoLista = Join-Path $PSScriptRoot 'arquivos-originais-gtav-enhanced.txt'

function Ler-Manifesto([string]$caminho) {
    $b = [IO.File]::ReadAllBytes($caminho)
    if ([BitConverter]::ToUInt32($b, 0) -ne 0x44BEC00C) { throw "formato desconhecido: $caminho" }
    $tamCab = [BitConverter]::ToUInt32($b, 4)
    $tamComp = [BitConverter]::ToUInt32($b, 12)
    $comprimido = $b[36] -band 1
    if ($comprimido) {
        # zlib: pula os 2 bytes do cabeçalho zlib e descomprime o deflate
        $ms = New-Object IO.MemoryStream($b, ($tamCab + 2), ($tamComp - 2))
        $ds = New-Object IO.Compression.DeflateStream($ms, [IO.Compression.CompressionMode]::Decompress)
        $out = New-Object IO.MemoryStream
        $ds.CopyTo($out)
        $dados = $out.ToArray()
    } else {
        $dados = New-Object byte[] ($b.Length - $tamCab)
        [Array]::Copy($b, $tamCab, $dados, 0, $dados.Length)
    }
    # Os nomes são FString: int32 tamanho (com o 0 final) + texto + 0. Pega só os que batem com o tamanho.
    $texto = [Text.Encoding]::GetEncoding(28591).GetString($dados)
    $nomes = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($m in [regex]::Matches($texto, '[\x20-\x7e]{1,400}(?=\x00)')) {
        $ini = $m.Index
        if ($ini -lt 4) { continue }
        if ([BitConverter]::ToInt32($dados, $ini - 4) -ne ($m.Length + 1)) { continue }
        $nomes.Add($m.Value.Replace('/', '\')) | Out-Null
    }
    return $nomes
}

$originais = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
if ($manifestos.Count -gt 0) {
    $origem = 'Epic'
    foreach ($mf in $manifestos) { foreach ($n in (Ler-Manifesto $mf.FullName)) { $originais.Add($n) | Out-Null } }
    if ($GerarLista) {
        $ver = (Get-Item -LiteralPath (Join-Path $jogo 'GTA5_Enhanced.exe')).VersionInfo.FileVersion
        # Só nomes que existem no disco: o manifesto também tem textos que não são arquivos (versão, argumentos do BattlEye…).
        $existem = $originais | Where-Object { Test-Path -LiteralPath (Join-Path $jogo $_) -PathType Leaf } | Sort-Object
        $linhas = @("# Arquivos originais do GTA V Enhanced, tirados do manifesto da Epic (exe $ver). Usado pelo limpar-pasta-jogo na Steam.") + $existem
        [IO.File]::WriteAllLines($GerarLista, $linhas, (New-Object Text.UTF8Encoding($false)))
        Sair 0 ("Lista gravada: {0} ({1} arquivos)" -f $GerarLista, @($existem).Count)
    }
} elseif (Test-Path -LiteralPath $arquivoLista) {
    $origem = 'Lista'
    foreach ($l in (Get-Content -LiteralPath $arquivoLista -Encoding UTF8)) { $l = $l.Trim(); if ($l -and -not $l.StartsWith('#')) { $originais.Add($l) | Out-Null } }
} else {
    Sair 2 "Não achei o manifesto da Epic (.egstore\*.manifest) nem a lista $arquivoLista. Rode o .bat da pasta ferramentas do .zip do GTA Co-op."
}
# Pastas que contêm algo original (para não mover uma pasta do jogo inteira)
$pastasOriginais = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach ($n in $originais) {
    $p = Split-Path -Parent $n
    while ($p) { $pastasOriginais.Add($p) | Out-Null; $p = Split-Path -Parent $p }
}
if (-not $originais.Contains('GTA5_Enhanced.exe') -or -not $originais.Contains('x64a.rpf')) {
    Sair 2 "A lista de originais não tem o GTA5_Enhanced.exe/x64a.rpf. Por segurança, não mexo em nada."
}
if ($origem -eq 'Epic') { Write-Host ("Manifesto da Epic: {0} arquivos originais." -f $originais.Count) }
else {
    Write-Host ("Sem manifesto da Epic (jogo da Steam?): usando a lista de {0} arquivos originais do GTA Co-op." -f $originais.Count)
    Write-Host "Só vou mover o que eu reconhecer como mod; o resto aparece como 'não reconhecido'." -ForegroundColor DarkYellow
}

# Steam: o que é da loja nunca sai. O que parece mod (nome conhecido, extensão, pasta) é "mod"; o resto, "desconhecido".
$daLoja = '^(steam_api(64)?\.dll|steam_appid\.txt|.*\.vdf|.*\.acf)$'
$nomesDeMod = '^(scripthookv.*|dinput8\.dll|xinput1_[34]\.dll|xinput9_1_0\.dll|version\.dll|winmm\.dll|dsound\.dll|dxgi\.dll|d3d1[12]\.dll|minhook.*\.dll|args\.txt|commandline\.txt|scripts|mods|plugins|gtacoop|ferramentas|licencas|reshade-shaders|menyoostuff|LEIA-ME\.md|SHA256\.txt)$'
$trechosDeMod = 'coop|rage|trainer|menyoo|lspdfr|reshade|enb|openiv|lemonui|nativeui|lidgren|newtonsoft|protobuf|maxmind|geolite|scripthook|asiloader'
function Classe($nome, $ePasta) {
    if ($origem -eq 'Epic') { return 'mod' }
    if ($nome -match $daLoja) { return 'loja' }
    if ($nome -match $nomesDeMod -or $nome -match $trechosDeMod) { return 'mod' }
    if (-not $ePasta -and $nome -match '\.(asi|log|ini)$') { return 'mod' }
    return 'desconhecido'
}

# ---------- 3. O que não é original ----------
# Mods de base e o GTA Co-op (ficam no modo Residuos). Caminhos relativos à pasta do jogo.
$base = @(
    'ScriptHookV.dll', 'dinput8.dll', 'xinput1_4.dll', 'args.txt', 'ScriptHookV.log', 'asiloader.log',
    'ScriptHookVDotNet.asi', 'ScriptHookVDotNet.ini', 'ScriptHookVDotNet2.dll', 'ScriptHookVDotNet3.dll', 'MinHook.x64.dll', 'ScriptHookVDotNet.log',
    'StraightToStoryMode.asi', 'StraightToStoryMode.log',
    'gtacoop.asi', 'gtacoop', 'scripts\GtaCoop.Game.dll',
    'ferramentas', 'licencas', 'LEIA-ME.md', 'SHA256.txt'   # do .zip do GTA Co-op, se alguém copiou tudo para a pasta do jogo
)
$baseSet = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
$base | ForEach-Object { $baseSet.Add($_) | Out-Null }

$itens = New-Object System.Collections.Generic.List[object]
function Varrer([string]$dir) {
    foreach ($e in (Get-ChildItem -LiteralPath $dir -Force)) {
        $rel = $e.FullName.Substring($jogo.Length + 1)
        if ($rel -ieq '.egstore') { continue }
        if ($e.PSIsContainer) {
            if ($pastasOriginais.Contains($rel)) { Varrer $e.FullName }          # pasta do jogo: olha dentro
            else {
                $c = Classe $e.Name $true
                if ($c -ne 'loja') { $itens.Add([pscustomobject]@{ Rel = $rel; Pasta = $true; Classe = $c; Tam = (Get-ChildItem -LiteralPath $e.FullName -Recurse -File -Force | Measure-Object Length -Sum).Sum }) }
            }
        } elseif (-not $originais.Contains($rel)) {
            $c = Classe $e.Name $false
            if ($c -ne 'loja') { $itens.Add([pscustomobject]@{ Rel = $rel; Pasta = $false; Classe = $c; Tam = $e.Length }) }
        }
    }
}
Varrer $jogo

function Eh-Base($rel) { $baseSet.Contains($rel) }
function Tam($n) { if ($n -ge 1MB) { '{0:N1} MB' -f ($n / 1MB) } elseif ($n -ge 1KB) { '{0:N0} KB' -f ($n / 1KB) } else { "$([int]$n) B" } }

# A pasta scripts\ não é original: no modo Residuos, olha dentro dela em vez de movê-la inteira.
function Itens-Do-Modo($modo) {
    $lista = New-Object System.Collections.Generic.List[object]
    foreach ($i in $itens) {
        if ($modo -eq 'Residuos' -and $i.Pasta -and $i.Rel -ieq 'scripts') {
            foreach ($f in (Get-ChildItem -LiteralPath (Join-Path $jogo 'scripts') -Force)) {
                $r = 'scripts\' + $f.Name
                if (-not (Eh-Base $r)) { $lista.Add([pscustomobject]@{ Rel = $r; Pasta = $f.PSIsContainer; Classe = 'mod'; Tam =$(if ($f.PSIsContainer) { (Get-ChildItem -LiteralPath $f.FullName -Recurse -File -Force | Measure-Object Length -Sum).Sum } else { $f.Length }) }) }
            }
            continue
        }
        if ($modo -eq 'Residuos' -and (Eh-Base $i.Rel)) { continue }
        if ($i.Classe -eq 'desconhecido' -and -not $IncluirDesconhecidos) { continue }
        # A pasta de onde este script está rodando (ex.: <jogo>\ferramentas) não é movida: ela está em uso agora.
        $cheio = Join-Path $jogo $i.Rel
        if ($i.Pasta -and ($PSScriptRoot + '\').StartsWith($cheio + '\', [StringComparison]::OrdinalIgnoreCase)) {
            Write-Host ("  (fica: {0}\ é de onde este script está rodando; apague à mão depois, se quiser)" -f $i.Rel) -ForegroundColor DarkYellow
            continue
        }
        $lista.Add($i)
    }
    return , $lista
}

Write-Host ""
if ($itens.Count -eq 0) { Sair 0 "A pasta já está só com os arquivos originais do jogo." }
Write-Host "Arquivos e pastas que NÃO são do jogo original:" -ForegroundColor Yellow
foreach ($i in $itens) {
    $tipo = if ($i.Classe -eq 'desconhecido') { 'não reconhecido (só sai se você confirmar)' }
            elseif ((Eh-Base $i.Rel) -or ($i.Rel -ieq 'scripts')) { 'mod de base / GTA Co-op' } else { 'OUTRO MOD / resto' }
    Write-Host ("  {0,-34} {1,10}  {2}" -f ($i.Rel + $(if ($i.Pasta) { '\' } else { '' })), (Tam $i.Tam), $tipo)
}
Write-Host ""

# ---------- 4. Escolher o modo ----------
if (-not $Modo) {
    Write-Host "O que fazer?"
    Write-Host "  [1] Deixar SÓ o jogo original (tira tudo acima, inclusive ScriptHookV e o GTA Co-op)"
    Write-Host "  [2] Tirar só os restos de OUTROS mods (mantém ScriptHookV, ScriptHookVDotNet e o GTA Co-op)"
    Write-Host "  [3] Nada (só queria ver a lista)"
    $r = Read-Host "Escolha 1, 2 ou 3"
    switch ($r.Trim()) { '1' { $Modo = 'Original' } '2' { $Modo = 'Residuos' } default { $Modo = 'Listar' } }
}
if ($Modo -eq 'Listar') { Sair 0 "Nada foi mexido." }

$desconhecidos = @($itens | Where-Object { $_.Classe -eq 'desconhecido' }).Count
if ($desconhecidos -gt 0 -and -not $IncluirDesconhecidos -and -not $Sim) {
    Write-Host ""
    Write-Host ("Há {0} item(ns) 'não reconhecido(s)': não estão na lista do jogo, mas também não parecem mod." -f $desconhecidos) -ForegroundColor DarkYellow
    Write-Host "Se algum for do jogo e sair por engano, 'Verificar integridade dos arquivos' na Steam traz de volta."
    $r = Read-Host "Mover esses também? (S = sim, Enter = não)"
    if ($r.Trim().ToUpperInvariant() -eq 'S') { $IncluirDesconhecidos = $true }
}

$mover = Itens-Do-Modo $Modo
if ($mover.Count -eq 0) { Sair 0 "Não há restos de outros mods: nada a mover." }

# ---------- 5. Conferências antes de mexer ----------
# O jogo desta pasta está aberto? O caminho do processo pode vir vazio (jogo aberto como administrador): então
# confere se o exe desta pasta está em uso.
function Jogo-Aberto {
    foreach ($proc in @(Get-Process -Name 'GTA5_Enhanced', 'GTA5_Enhanced_BE', 'PlayGTAV' -ErrorAction SilentlyContinue)) {
        $c = $null; try { $c = $proc.Path } catch { }
        if ($c -and $c.StartsWith($jogo + '\', [StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    foreach ($exe in 'GTA5_Enhanced.exe', 'GTA5_Enhanced_BE.exe', 'PlayGTAV.exe') {
        $f = Join-Path $jogo $exe
        if (-not (Test-Path -LiteralPath $f)) { continue }
        try { $s = [IO.File]::Open($f, 'Open', 'ReadWrite', 'None'); $s.Close() } catch { return $true }
    }
    return $false
}
if (Jogo-Aberto) { Sair 3 "O jogo está aberto. Feche o GTA V e rode de novo." }

$destRaiz = Join-Path (Split-Path -Parent $jogo) 'GTAV-arquivos-removidos'
$dest = Join-Path $destRaiz (Get-Date -Format 'yyyy-MM-dd_HH-mm-ss')

Write-Host ("Vou MOVER {0} item(ns) para:" -f $mover.Count)
Write-Host "  $dest"
foreach ($i in $mover) { Write-Host ("    {0}" -f $i.Rel) }
if (-not $Sim) {
    $ok = Read-Host "Confirma? (digite S e Enter)"
    if ($ok.Trim().ToUpperInvariant() -ne 'S') { Sair 0 "Cancelado. Nada foi mexido." }
}

# ---------- 6. Mover e conferir ----------
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$log = New-Object System.Collections.Generic.List[string]
$log.Add("Pasta do jogo: $jogo")
$log.Add("Modo: $Modo   Data: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')")
$log.Add("Para desfazer: copie o conteúdo desta pasta de volta para a pasta do jogo (com o jogo fechado).")
$log.Add("")
$falhas = 0
foreach ($i in $mover) {
    $de = Join-Path $jogo $i.Rel
    $para = Join-Path $dest $i.Rel
    try {
        $antes = if ($i.Pasta) { @(Get-ChildItem -LiteralPath $de -Recurse -File -Force).Count } else { 1 }
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $para) | Out-Null
        Move-Item -LiteralPath $de -Destination $para
        $depois = if ($i.Pasta) { @(Get-ChildItem -LiteralPath $para -Recurse -File -Force).Count } else { [int](Test-Path -LiteralPath $para) }
        if ((Test-Path -LiteralPath $de) -or $depois -ne $antes) { throw "conferência falhou ($antes arquivos antes, $depois depois)" }
        $log.Add(("MOVIDO  {0}{1}  ({2} arquivo(s), {3})" -f $i.Rel, $(if ($i.Pasta) { '\' } else { '' }), $antes, (Tam $i.Tam)))
        Write-Host ("  ok  {0}" -f $i.Rel) -ForegroundColor Green
    } catch {
        $falhas++
        $log.Add(("FALHOU  {0}: {1}" -f $i.Rel, $_.Exception.Message))
        Write-Host ("  ERRO {0}: {1}" -f $i.Rel, $_.Exception.Message) -ForegroundColor Red
    }
}
# A pasta scripts\ que ficou vazia no modo Residuos fica (o SHVDNE usa).
[IO.File]::WriteAllLines((Join-Path $dest 'lista.txt'), $log, (New-Object Text.UTF8Encoding($true)))

Write-Host ""
Write-Host "Lista do que foi movido: $(Join-Path $dest 'lista.txt')"
if ($falhas -gt 0) { Sair 1 "$falhas item(ns) não foram movidos (veja acima). Se for falta de permissão, rode o .bat como administrador." }
$verificar = if ($origem -eq 'Epic') { "'Verificar' na Epic (Biblioteca > GTA V Enhanced > ... > Gerenciar)" } else { "Steam: botão direito no jogo > Propriedades > Arquivos instalados > 'Verificar integridade dos arquivos'" }
if (-not $IncluirDesconhecidos -and $desconhecidos -gt 0) {
    Write-Host ("Ficaram {0} item(ns) não reconhecido(s) (listados acima). Para tirar também: rode de novo e responda S." -f $desconhecidos) -ForegroundColor DarkYellow
}
if ($Modo -eq 'Original') {
    Sair 0 "Pronto: os mods saíram da pasta do jogo. Para conferir os arquivos do jogo: $verificar."
}
Sair 0 "Pronto: os restos de outros mods saíram; ScriptHookV, ScriptHookVDotNet e o GTA Co-op continuam."
