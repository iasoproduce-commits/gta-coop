@echo off
rem Deixa a pasta do GTA V Enhanced (Epic) so com os arquivos originais do jogo.
rem Nada e apagado: o que sai e MOVIDO para a pasta GTAV-arquivos-removidos, ao lado da pasta do jogo.
rem Pode passar opcoes: limpar-pasta-jogo.bat -Pasta "D:\Epic Games\GTAVEnhanced" -Modo Listar
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0limpar-pasta-jogo.ps1" %*
echo.
pause
