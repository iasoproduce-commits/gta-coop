@echo off
rem Atualiza o GTA Co-op para a ultima versao publicada. Feche o jogo antes.
rem Baixa o pacote, confere o SHA-256, guarda os arquivos antigos em gtacoop\backup\ e instala.
rem O seu gtacoop\config.ini e o ScriptHookVDotNet.ini NAO sao trocados.
rem Uso: atualizar.bat            (fonte padrao)
rem      atualizar.bat <fonte>    (outra fonte: link "raw" do GitHub ou uma pasta, para testes)
set "GTACOOP_FONTE_PADRAO=https://raw.githubusercontent.com/iasoproduce-commits/gta-coop/main"
rem Roda de uma copia em %TEMP%: a atualizacao pode trocar este proprio arquivo.
if /i not "%~dp0"=="%TEMP%\gtacoop-atualizar\" (
    if not exist "%TEMP%\gtacoop-atualizar" mkdir "%TEMP%\gtacoop-atualizar"
    copy /y "%~f0" "%TEMP%\gtacoop-atualizar\atualizar.bat" >nul
    set "GTACOOP_ORIGEM=%~dp0"
    call "%TEMP%\gtacoop-atualizar\atualizar.bat" %*
    exit /b
)
set "GTACOOP_FONTE=%~1"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$f='%~f0'; $p=(Get-Content -LiteralPath $f -Raw -Encoding UTF8) -split ('#'+'#POWERSHELL#'+'#'); Invoke-Expression $p[$p.Length-1]"
echo.
pause
exit /b

##POWERSHELL##
$ErrorActionPreference = 'Stop'
function Pare([string]$t) { Write-Host $t -ForegroundColor Red; throw 'parar' }
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

    # ---------- de onde baixar ----------
    $fonte = if ($env:GTACOOP_FONTE) { $env:GTACOOP_FONTE.Trim('"') } else { $env:GTACOOP_FONTE_PADRAO }
    if (-not $fonte -or $fonte -like ('*__' + 'FONTE__*')) { Pare "Este atualizar.bat não tem a fonte das versões configurada. Peça o atualizar.bat novo a quem te passou o mod." }
    $fonte = $fonte.TrimEnd('/', '\')
    $web = $fonte -match '^https?://'
    function Ler-Texto($rel) {
        if ($web) { return (Invoke-WebRequest -UseBasicParsing -Uri ("$fonte/$rel" + '?t=' + [DateTime]::UtcNow.Ticks) -TimeoutSec 30).Content }
        return [IO.File]::ReadAllText((Join-Path $fonte $rel), [Text.Encoding]::UTF8)
    }
    function Baixar($rel, $destino) {
        if ($web) { Invoke-WebRequest -UseBasicParsing -Uri ("$fonte/$rel") -OutFile $destino -TimeoutSec 300 }
        else { Copy-Item -LiteralPath (Join-Path $fonte $rel) -Destination $destino -Force }
    }

    # ---------- achar a pasta do jogo ----------
    $candidatas = New-Object System.Collections.Generic.List[string]
    if ($env:GTACOOP_PASTA) { $candidatas.Add($env:GTACOOP_PASTA.Trim('"')) }
    if ($env:GTACOOP_ORIGEM) {
        $o = $env:GTACOOP_ORIGEM.TrimEnd('\')
        $candidatas.Add($o); $candidatas.Add((Split-Path -Parent $o)); $candidatas.Add((Split-Path -Parent (Split-Path -Parent $o)))
    }
    $dat = Join-Path $env:ProgramData 'Epic\UnrealEngineLauncher\LauncherInstalled.dat'
    if (Test-Path -LiteralPath $dat) { try { (Get-Content -LiteralPath $dat -Raw | ConvertFrom-Json).InstallationList | ForEach-Object { if ($_.InstallLocation) { $candidatas.Add($_.InstallLocation) } } } catch { } }
    $libs = New-Object System.Collections.Generic.List[string]
    foreach ($chave in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam') {
        try { $v = Get-ItemProperty -Path $chave -ErrorAction Stop; foreach ($s in @($v.SteamPath, $v.InstallPath)) { if ($s) { $libs.Add($s.Replace('/', '\')) } } } catch { }
    }
    foreach ($s in @($libs)) {
        $vdf = Join-Path $s 'steamapps\libraryfolders.vdf'
        if (Test-Path -LiteralPath $vdf) { foreach ($m in [regex]::Matches((Get-Content -LiteralPath $vdf -Raw), '"path"\s+"([^"]+)"')) { $libs.Add($m.Groups[1].Value.Replace('\\', '\')) } }
    }
    foreach ($d in (Get-PSDrive -PSProvider FileSystem -ErrorAction SilentlyContinue)) {
        foreach ($sub in 'SteamLibrary', 'Steam', 'Program Files (x86)\Steam', 'Program Files\Steam') { $libs.Add((Join-Path $d.Root $sub)) }
        foreach ($sub in 'Program Files\Rockstar Games\Grand Theft Auto V Enhanced', 'Epic Games\GTAVEnhanced') { $candidatas.Add((Join-Path $d.Root $sub)) }
    }
    foreach ($lib in $libs) {
        $common = Join-Path $lib 'steamapps\common'
        if (Test-Path -LiteralPath $common) { Get-ChildItem -LiteralPath $common -Directory -ErrorAction SilentlyContinue | ForEach-Object { $candidatas.Add($_.FullName) } }
    }
    $jogo = $null
    foreach ($c in $candidatas) { if ($c -and (Test-Path -LiteralPath (Join-Path $c 'GTA5_Enhanced.exe'))) { $jogo = (Resolve-Path -LiteralPath $c).Path.TrimEnd('\'); break } }
    if (-not $jogo) {
        $r = (Read-Host "Não achei a pasta do GTA V Enhanced. Cole o caminho dela (onde fica o GTA5_Enhanced.exe)").Trim().Trim('"')
        if ($r -and (Test-Path -LiteralPath (Join-Path $r 'GTA5_Enhanced.exe'))) { $jogo = (Resolve-Path -LiteralPath $r).Path.TrimEnd('\') } else { Pare "Nessa pasta não tem GTA5_Enhanced.exe." }
    }
    Write-Host "Pasta do jogo: $jogo"
    # O jogo DESTA pasta está aberto? (o caminho do processo pode vir vazio com o jogo como admin: então confere se o exe está em uso)
    $aberto = $false
    foreach ($proc in @(Get-Process -Name 'GTA5_Enhanced', 'GTA5_Enhanced_BE', 'PlayGTAV' -ErrorAction SilentlyContinue)) {
        $c = $null; try { $c = $proc.Path } catch { }
        if ($c -and $c.StartsWith($jogo + '\', [StringComparison]::OrdinalIgnoreCase)) { $aberto = $true }
    }
    foreach ($exe in 'GTA5_Enhanced.exe', 'PlayGTAV.exe') {
        $fx = Join-Path $jogo $exe
        if (Test-Path -LiteralPath $fx) { try { $s = [IO.File]::Open($fx, 'Open', 'ReadWrite', 'None'); $s.Close() } catch { $aberto = $true } }
    }
    if ($aberto) { Pare "O jogo está aberto. Feche o GTA V e rode de novo." }

    # ---------- versões ----------
    $instalada = '(nenhuma)'
    $vtxt = Join-Path $jogo 'gtacoop\versao.txt'
    if (Test-Path -LiteralPath $vtxt) { $m = Select-String -LiteralPath $vtxt -Pattern '^pacote=(.+)$' | Select-Object -First 1; if ($m) { $instalada = $m.Matches[0].Groups[1].Value.Trim() } }
    elseif (Test-Path -LiteralPath (Join-Path $jogo 'gtacoop.asi')) { $instalada = '(anterior à 0.6.1)' }
    Write-Host "Versão instalada: $instalada"
    Write-Host "Procurando a última versão em: $fonte"
    $ultima = (Ler-Texto 'ultima.json') | ConvertFrom-Json
    if (-not $ultima.pacote -or -not $ultima.arquivo -or $ultima.sha256 -notmatch '^[0-9a-fA-F]{64}$') { Pare "O ultima.json da fonte está incompleto." }
    Write-Host ("Última versão: {0}  ({1})" -f $ultima.pacote, $ultima.data)
    if ($ultima.notas) { Write-Host ("  Novidades: " + $ultima.notas) }
    if ($instalada -eq $ultima.pacote) { Write-Host "Você já está na última versão. Nada a fazer." -ForegroundColor Green; return }

    # ---------- baixar e conferir ----------
    $tmp = Join-Path $env:TEMP ('gtacoop-atualizar\' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    New-Item -ItemType Directory -Force -Path $tmp | Out-Null
    $zip = Join-Path $tmp 'pacote.zip'
    Write-Host "Baixando $($ultima.arquivo)..."
    Baixar $ultima.arquivo $zip
    $sha = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($sha -ne $ultima.sha256.ToLowerInvariant()) { Pare "O arquivo baixado não confere (SHA-256 $sha, esperado $($ultima.sha256)). Nada foi instalado; tente de novo." }
    Write-Host "SHA-256 confere."
    $ext = Join-Path $tmp 'pacote'
    Expand-Archive -LiteralPath $zip -DestinationPath $ext -Force
    foreach ($obrig in 'gtacoop.asi', 'gtacoop\core.dll', 'scripts\GtaCoop.Game.dll') {
        if (-not (Test-Path -LiteralPath (Join-Path $ext $obrig))) { Pare "O pacote baixado não tem $obrig. Nada foi instalado." }
    }

    # ---------- o que vai para onde ----------
    # Tudo do pacote vai para a pasta do jogo, menos: LEIA-ME.md e SHA256.txt (ficam em gtacoop\), ferramentas\ e
    # licencas\ (vão para dentro de gtacoop\) e o gtacoop\config.ini, que só é copiado se ainda não existir.
    $plano = New-Object System.Collections.Generic.List[object]
    foreach ($a in (Get-ChildItem -LiteralPath $ext -Recurse -File)) {
        $rel = $a.FullName.Substring($ext.Length + 1)
        $destRel = $rel
        if ($rel -ieq 'LEIA-ME.md' -or $rel -ieq 'SHA256.txt') { $destRel = 'gtacoop\' + $rel }
        elseif ($rel -like 'ferramentas\*' -or $rel -like 'licencas\*') { $destRel = 'gtacoop\' + $rel }
        # Configurações do jogador: só vão se ainda não existirem.
        if (($destRel -ieq 'gtacoop\config.ini' -or $destRel -ieq 'ScriptHookVDotNet.ini') -and (Test-Path -LiteralPath (Join-Path $jogo $destRel))) { continue }
        $plano.Add([pscustomobject]@{ De = $a.FullName; Rel = $destRel })
    }

    # ---------- backup do que vai ser trocado ----------
    $bkp = Join-Path $jogo ('gtacoop\backup\' + (Get-Date -Format 'yyyy-MM-dd_HH-mm-ss') + '_' + ($instalada -replace '[^\w\.\-]', ''))
    $guardados = 0
    foreach ($i in $plano) {
        $atual = Join-Path $jogo $i.Rel
        if (Test-Path -LiteralPath $atual) {
            $b = Join-Path $bkp $i.Rel
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $b) | Out-Null
            Copy-Item -LiteralPath $atual -Destination $b -Force
            $guardados++
        }
    }
    if ($guardados -gt 0) { Write-Host "Arquivos antigos guardados em: $bkp ($guardados)" }

    # ---------- instalar ----------
    $copiados = 0
    foreach ($i in $plano) {
        $dest = Join-Path $jogo $i.Rel
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dest) | Out-Null
        Copy-Item -LiteralPath $i.De -Destination $dest -Force
        if ((Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $i.De -Algorithm SHA256).Hash) { Pare "Falhou ao copiar $($i.Rel). Os antigos estão em $bkp." }
        $copiados++
    }
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    Write-Host ""
    Write-Host ("Pronto: GTA Co-op atualizado de {0} para {1} ({2} arquivos)." -f $instalada, $ultima.pacote, $copiados) -ForegroundColor Green
    Write-Host "Da próxima vez, rode o atualizar.bat que ficou em: $(Join-Path $jogo 'gtacoop\ferramentas')"
} catch {
    if ($_.Exception.Message -ne 'parar') { Write-Host ("Erro: " + $_.Exception.Message) -ForegroundColor Red }
}
