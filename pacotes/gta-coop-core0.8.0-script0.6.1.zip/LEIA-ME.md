# GTA Co-op — instalação e como jogar (rascunho)

> Rascunho da Fase 7 (2026-11-07). Ainda não foi testado entre dois PCs. Cada lado foi testado no mesmo PC, contra um
> host ou um jogador simulado.

Dois jogadores no modo história do GTA V. Quem **hospeda** joga a história normalmente, com o save dele. Quem **entra**
controla o parceiro da missão (Lamar, Trevor, Lester…) e, fora das missões, anda com um personagem livre.
O mesmo pacote serve para os dois: quem hospeda e quem entra se escolhe no jogo, com **F10**.

## Antes de tudo

- **Nunca entre no GTA Online com o mod instalado.** Use só o modo história.
- Os dois precisam do **GTA V Enhanced (PC) na mesma versão**. Testado na **1.0.1158.16**. Se a sua for outra, o mod
  avisa na tela ao carregar (pode funcionar ou não).
- Para jogar pela internet, os dois precisam estar na mesma rede virtual (ex.: **Radmin VPN**, gratuito: um cria a rede
  e o outro entra nela). Na mesma casa, a rede local basta.

## 1. Baixe o ScriptHookV (o único que não vem no .zip)

O autor do ScriptHookV não permite que ele seja repassado em outros pacotes, então cada um baixa o dele:
em **dev-c.com**, página do ScriptHookV (a versão mais nova). Do zip dele, copie para a pasta do jogo (onde fica o
`GTA5_Enhanced.exe`) o conteúdo da pasta **`bin\`**, **menos o `NativeTrainer.asi`** (ele usa a tecla F4, a mesma do
console do ScriptHookVDotNet):
- `ScriptHookV.dll`, `dinput8.dll`, `xinput1_4.dll` (o ScriptHookV e o carregador de mods)
- `args.txt` (desliga o anti-cheat BattlEye no modo história; sem ele o jogo pode bloquear os mods)

O **ScriptHookVDotNet Enhanced** (github.com/Chiheb-Bacha) já vem no `.zip` do GTA Co-op, com as licenças em
`licencas\`.

## 2. Instale o GTA Co-op

0. **Já testou outro mod de co-op (ou outros mods) nessa pasta?** Com o jogo fechado, rode antes
   `ferramentas\limpar-pasta-jogo.bat` direto da pasta onde o `.zip` foi extraído (não precisa copiar para a pasta
   do jogo: ele acha o jogo sozinho, na Epic ou na Steam). Ele compara a pasta com a lista oficial de arquivos do jogo e
   pergunta: **[1]** deixar só o jogo original ou **[2]** tirar só os restos de outros mods (mantém ScriptHookV,
   ScriptHookVDotNet e o GTA Co-op). Nada é apagado: o que sai vai para a pasta `GTAV-arquivos-removidos`, ao lado
   da pasta do jogo, com uma `lista.txt`. Funciona na **Epic** e na **Steam**. Na Steam ele só tira o que reconhece
   como mod; o que não reconhecer aparece na lista e só sai se você responder **S**. Se algo do jogo sair por engano,
   use "Verificar integridade dos arquivos" na Steam.
1. Abra o `.zip`. Confira, se quiser, os SHA-256 em `SHA256.txt`.
2. Copie para a pasta do jogo, mantendo as pastas (as pastas `ferramentas` e `licencas` e os `.md`/`.txt` não precisam):
   - `gtacoop.asi` e a pasta `gtacoop\` (core, config, perfis)
   - `scripts\GtaCoop.Game.dll` (vai para a pasta `scripts` do jogo)
   - `ScriptHookVDotNet.asi`, `ScriptHookVDotNet.ini`, `ScriptHookVDotNet2.dll`, `ScriptHookVDotNet3.dll`,
     `MinHook.x64.dll` (o ScriptHookVDotNet Enhanced)
3. Abra o jogo no modo história. Aparece uma mensagem do ScriptHookV no começo e, no canto, o aviso do GTA Co-op.
4. Nada do jogo original é alterado. Para desinstalar: rode `ferramentas\limpar-pasta-jogo.bat` e escolha **[1]**.

## Atualizar

Com o jogo fechado, rode **`gtacoop\ferramentas\atualizar.bat`** (dentro da pasta do jogo; ou o `ferramentas\atualizar.bat`
do `.zip`). Ele confere se há versão nova, baixa, confere o SHA-256, guarda os arquivos antigos em `gtacoop\backup\` e
instala. O seu `gtacoop\config.ini` (IP, nome…) e o `ScriptHookVDotNet.ini` não são trocados. Se já estiver na última
versão, ele só avisa. Uma versão recém-publicada pode levar até uns 5 minutos para aparecer.

## 3. Só para quem vai HOSPEDAR: libere a porta no firewall (uma vez)

No PC de quem hospeda, como administrador:

```
powershell -ExecutionPolicy Bypass -File ferramentas\firewall-radmin.ps1
```

O script cria só uma regra de entrada UDP na porta 27500 (perfil Público, que é como o Windows costuma ver a rede do
Radmin). Para ver antes o que ele faz: `-SoMostrar`. Para desfazer: `-Remover`. Quem só entra não precisa disso.
Ao hospedar pela primeira vez, se o Windows perguntar sobre o firewall, escolha **Permitir**.

## 4. Jogando

1. Os dois abrem o jogo no modo história.
2. Quem hospeda aperta **F10** → **1 (Hospedar)**. Aparece na tela o IP para passar ao amigo (o do Radmin, `26.x.x.x`,
   vem primeiro).
3. Quem entra aperta **F10** → **2 (Entrar no jogo de um amigo)** e digita o IP no teclado do jogo (ou `IP:porta`, se
   o host mudou a porta). O mod lembra o último IP: da próxima vez é só confirmar com Enter.
4. Conectado, quem entrou vê o personagem do host e, na missão, o seu objetivo embaixo da tela (em amarelo), com
   marcador e rota no GPS. Nas cenas (cutscenes) do host aparece "Cena do jogador 1": espere.
5. **F10** de novo desliga a rede. Se a conexão cair, o mod tenta reconectar sozinho.

## 5. Config (opcional): `gtacoop\config.ini`

Não precisa mexer. Para quem quiser:

```
papel = perguntar   (padrão: o F10 abre o menu; "host" ou "cliente" fazem o F10 ir direto)
ip_host =           (o último IP digitado no F10 fica aqui)
porta = 27500       (a mesma nos dois)
nome = seu nome
```

Com conexão "Relay" no Radmin (mais lenta), aumente `atraso_interpolacao_ms` para 200–250.

## Problemas conhecidos (rascunho)

- Ainda não testado entre dois PCs.
- O personagem livre e a troca para o parceiro na missão foram testados só no PC do host.
